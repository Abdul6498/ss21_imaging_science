Abdul Rehman (3440146) M.Sc. INFOTECH
An Trieu (3523966) M.Sc. INFOTECH
Khanh Quynh Nguyen (3517671) M.Sc. INFOTECH
Valentina Roldan (3519666) M.Sc. INFOTECH

3(c)
- q = 3 with no noise
MSE = 74.94
PSNR = 29.38dB

- q = 3 with a = 0.25 Gaussian noise
MSE = 139.11
PSNR = 26.70

- q = 3 with a = 0.25 uniform noise
MSE = 92.91
PSNR = 28.45

Conclusions:
- image quality decreases as a increases and/or q decreases
- MSE increases more for Gaussian noise comparing to uniform noise for the same value of a because the variance of uniform noise is (2a)^2/12 while gaussian is a^2